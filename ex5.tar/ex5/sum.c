//
// Created by shjda on 2018/6/19.
//

#include "sum.h"
int sum (int a, int b) { return a+b; }