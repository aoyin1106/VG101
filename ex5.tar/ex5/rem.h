//
// Created by shjda on 2018/6/19.
//

#ifndef EX5_REM_H
#define EX5_REM_H
int rem (int a, int b);
#endif //EX5_REM_H
