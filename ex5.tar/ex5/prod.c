//
// Created by shjda on 2018/6/19.
//

#include "prod.h"
int prod (int a, int b) { return a*b; }