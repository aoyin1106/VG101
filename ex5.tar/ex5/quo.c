//
// Created by shjda on 2018/6/19.
//

#include "quo.h"
int quo (int a, int b) { return a/b; }