//
// Created by shjda on 2018/6/19.
//

#ifndef EX5_QUO_H
#define EX5_QUO_H
int quo (int a, int b);
#endif //EX5_QUO_H
