//
// Created by shjda on 2018/6/19.
//

#include "mpow.h"
long int mpow (int a, int b) { return pow(a,b); }