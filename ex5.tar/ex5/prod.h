//
// Created by shjda on 2018/6/19.
//

#ifndef EX5_PROD_H
#define EX5_PROD_H
int prod (int a, int b);
#endif //EX5_PROD_H
