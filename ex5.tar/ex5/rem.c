//
// Created by shjda on 2018/6/19.
//

#include "rem.h"
int rem (int a, int b) { return a%b; }