//
// Created by shjda on 2018/6/19.
//

#ifndef EX5_MPOW_H
#define EX5_MPOW_H
long int mpow (int a, int b);
#endif //EX5_MPOW_H
